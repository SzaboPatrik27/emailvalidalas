const emailPattern = /^[^\s@]{3,}@[^\s@]{3,}\.[^\s@]{2,}$/
const email = "szabopatrik@turr.hu"
const jelszoPattern = document.getElementById(jelszo).value
const jelszo = "Trutyma28#"

console.log(email.match(emailPattern2));





function ellenorzesEmail(){
    const email = document.getElementById('email').value.trim()

    if(email.match(emailPattern))
    ('Email megfelelő')

    else{
        ('Nem megfelelő email struktúra')
    }
}   
function ellenorzesJelszo(){
    const jelszo = document.getElementById(jelszo).value.trim()
    if(jelszo.value == ""){
        alert("Ki kell tölteni a mezőt!")
        
    }

    if(email.match(emailPattern))
    ('Jelszó megfelelő')

    else{
        ('Nem megfelelő Jelszó struktúra')
    }
}